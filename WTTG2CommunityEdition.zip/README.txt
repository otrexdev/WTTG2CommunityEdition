Welcome to the Game 2: Community Edition

HOW TO INSTALL:
- Extract the WTTG2_Data folder into the game's installation directory, overwriting any existing files if prompted. WARNING: Do not delete the folder from your game installation.

HOW TO UNINSTALL:
- Verify the integrity of game files through Steam